#!/bin/sh
wget https://raw.githubusercontent.com/Unidata/TdsConfig/master/remotetest/config.zip -O config.zip
jar xf config.zip
