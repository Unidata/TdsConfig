#!/bin/sh
wget https://raw.githubusercontent.com/Unidata/TdsConfig/master/idd/config.zip
jar xf config.zip
